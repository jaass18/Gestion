==========================================
This Codes Is Origin By abejali
Date 	: 23/01/2007
Author	: abejali.com
Title	: Multiple selection using checbox
email	: abejali@yahoo.com
Sripting: PHP and AJAX
==========================================


This is a sample for you to get some Idea on making 
multiple selections Script Using PHP and AJAX technology.

I have tried to find multiple selection script by using 
checkbox that is not directly Been processed on submit form. 
There are too many examples outside but almost not exactly 
what I want.So create by myself and I want to share it with you.

Since I have created this script using PHP 4,
it supposed not to come out with any  major problem with PHP 5++

If You Feel Lucky with this code, Why not just buy me some coffee :)


Manual Instruction:
===================
Upload All Files into Your Server And Feel Good To Test.

Optional For PHP 5 User
1- Edit the file getifo.php into  PHP 5 code that 
I have commented inside  the code

